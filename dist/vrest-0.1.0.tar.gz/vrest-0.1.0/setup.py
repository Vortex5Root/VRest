# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['vrest']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.31.0,<3.0.0']

setup_kwargs = {
    'name': 'vrest',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Welcome to VRest\n\nVRest is a powerful Python library designed for simplifying the process of making RESTful API calls. It provides an intuitive and user-friendly interface, enabling developers to effortlessly create and execute API requests.\n\n## Installation\n\nTo get started with VRest, you can easily install it using Poetry, a dependency management tool. Follow the instructions below to add VRest to your project:\n\n```bash\npoetry add git+https://github.com/Vortex5Root/VRest.git\n```\n\nBy running this command, Poetry will fetch the latest version of VRest from the specified Git repository and add it as a dependency to your project.\n\n## Usage\n\n### Creating a Dictionary\n\nVRest requires a configuration dictionary that defines the API endpoints and their associated request details. This dictionary is structured in JSON format. Here\'s an example of how it should be organized:\n\n```json\n{\n    "end_point": "<url>",\n    "<function_name>": {\n        "method": "<GET, POST, PUT, DELETE>",\n        "<json, parms>": {\n            "<var_name>": {},\n            ...\n        },\n        ...\n    },\n    ...\n}\n```\n\nTo customize the dictionary for your specific API, replace `<url>` with the base URL of your API and `<function_name>`, `<method>`, `<json, parms>`, and `<var_name>` with appropriate values that correspond to your API\'s structure.\n\n### Example\n\nHere\'s a practical example to demonstrate how VRest can be utilized within your Python code:\n\n```python\n# Import VRest\nfrom vrest import RestAPI\n# Import required modules\nimport json\n\n# Load the configuration dictionary from a file\nconfig = {}\nwith open("<Dictionary_File>.json", "r") as config_file:\n    config = json.loads(config_file.read())\n\n# Create a RestAPI object\napi = RestAPI(config)\n\n# Set the API endpoint path\napi.path = "<Path>"\n\n# Set the command\napi.sub_dir = "<Command>"\n\n# Execute the API call\napi.exec({})\n```\n\nEnsure that you replace `"<Dictionary_File>.json"` with the actual path to your configuration file. Customize `<Path>` and `<Command>` based on your specific API requirements.\n\n## Contributing\n\nIf you would like to contribute to the development of VRest, we welcome your contributions! Feel free to submit pull requests or open issues on the GitHub repository at [https://github.com/Vortex5Root/VRest](https://github.com/Vortex5Root/VRest).\n\n## License\n\nVRest is released under the [MIT License](https://opensource.org/licenses/MIT), granting you the freedom to utilize and modify the library according to your needs.\n',
    'author': 'VortexRoot',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
